const API_BASE = 'http://localhost:5000/api';

async function api(endpoint, options = {}) {
  const token = localStorage.getItem('token');
  const headers = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
    ...options.headers
  };

  try {
    const res = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers
    });
    
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Request failed' }));
      throw new Error(err.error || 'Request failed');
    }
    return await res.json();
  } catch (e) {
    // Fallback to mock data if backend is not running
    console.warn('API offline, using mock data:', e.message);
    return mockFallback(endpoint, options);
  }
}

// Mock fallback so the UI works even without backend
function mockFallback(endpoint, options) {
  const mock = window.__MOCK_DB || null;
  if (!mock) return [];

  if (endpoint === '/stats') {
    return {
      totalShops: mock.shops.length,
      totalBooks: mock.books.length,
      totalOrders: mock.orders.length,
      totalUsers: mock.users.length,
      pendingOrders: mock.orders.filter(o => o.status !== 'delivered').length,
      lowStock: mock.inventory.filter(i => i.quantity <= i.minStock).length,
      totalRevenue: mock.orders.reduce((s, o) => s + o.total, 0),
      activeDeliveries: mock.deliveries.filter(d => d.status !== 'delivered').length
    };
  }
  if (endpoint === '/books') return mock.books;
  if (endpoint === '/shops') return mock.shops;
  if (endpoint === '/orders') {
    return mock.orders.map(o => ({
      ...o,
      customer: mock.users.find(u => u.id === o.customerId),
      shop: mock.shops.find(s => s.id === o.shopId),
      items: o.items.map(it => ({ ...it, book: mock.books.find(b => b.id === it.bookId) }))
    }));
  }
  if (endpoint === '/inventory') {
    return mock.inventory.map(inv => ({
      ...inv,
      book: mock.books.find(b => b.id === inv.bookId),
      shop: mock.shops.find(s => s.id === inv.shopId)
    }));
  }
  if (endpoint === '/purchase-orders') {
    return mock.purchaseOrders.map(po => ({
      ...po,
      shop: mock.shops.find(s => s.id === po.shopId),
      distributor: mock.users.find(u => u.id === po.distributorId),
      items: po.items.map(it => ({ ...it, book: mock.books.find(b => b.id === it.bookId) }))
    }));
  }
  if (endpoint === '/deliveries') {
    return mock.deliveries.map(d => ({
      ...d,
      order: mock.orders.find(o => o.id === d.orderId),
      partner: mock.users.find(u => u.id === d.partnerId)
    }));
  }
  if (endpoint === '/distributors') return mock.users.filter(u => u.role === 'distributor');
  if (endpoint === '/users') return mock.users.map(({password, ...u}) => u);
  if (endpoint === '/distributor-inventory') {
    return mock.distributorInventory.map(inv => ({
      ...inv,
      book: mock.books.find(b => b.id === inv.bookId)
    }));
  }
  return [];
}

// Expose for offline mode
window.api = api;
