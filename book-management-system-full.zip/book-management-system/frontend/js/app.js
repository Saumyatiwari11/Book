/* =====================================================
   BookFlow – Main Application
   ===================================================== */

let currentUser = null;
let currentPage = 'dashboard';

// -------------------- INIT --------------------
document.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('user');
  if (saved) {
    currentUser = JSON.parse(saved);
    showApp();
  }
  
  document.getElementById('loginForm').addEventListener('submit', handleLogin);
  
  // Load mock DB for offline mode
  loadMockDB();
});

async function loadMockDB() {
  try {
    const res = await fetch('../backend/data/db.json');
    if (res.ok) window.__MOCK_DB = await res.json();
  } catch (e) {
    // Embedded fallback
    window.__MOCK_DB = {
      users: [
        {id:'u1',name:'Super Admin',email:'admin@bookflow.com',password:'admin123',role:'admin',avatar:'SA'},
        {id:'u2',name:'Riya Sharma',email:'owner@shop.com',password:'owner123',role:'shop_owner',shopId:'s1',avatar:'RS'},
        {id:'u3',name:'Amit Verma',email:'dist@warehouse.com',password:'dist123',role:'distributor',avatar:'AV'},
        {id:'u4',name:'Rahul Delivery',email:'delivery@courier.com',password:'del123',role:'delivery',avatar:'RD'},
        {id:'u5',name:'Priya Customer',email:'customer@mail.com',password:'cust123',role:'customer',avatar:'PC'}
      ],
      shops: [
        {id:'s1',name:'BookNest Central',ownerId:'u2',address:'12 MG Road, Bengaluru',city:'Bengaluru',phone:'+91 98765 43210',status:'active'},
        {id:'s2',name:'PageTurners Hub',ownerId:'u2',address:'45 Park Street, Kolkata',city:'Kolkata',phone:'+91 87654 32109',status:'active'}
      ],
      books: [
        {id:'b1',isbn:'9780143458906',title:'The Psychology of Money',author:'Morgan Housel',publisher:'Jaico',category:'Finance',price:399,wholesalePrice:280,cover:'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=200&h=280&fit=crop'},
        {id:'b2',isbn:'9788172234980',title:'Atomic Habits',author:'James Clear',publisher:'Random House',category:'Self-Help',price:499,wholesalePrice:350,cover:'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=200&h=280&fit=crop'},
        {id:'b3',isbn:'9789386224569',title:'Ikigai',author:'Héctor García',publisher:'Penguin',category:'Lifestyle',price:350,wholesalePrice:240,cover:'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=200&h=280&fit=crop'},
        {id:'b4',isbn:'9780143445500',title:'Rich Dad Poor Dad',author:'Robert Kiyosaki',publisher:'Plata',category:'Finance',price:299,wholesalePrice:200,cover:'https://images.unsplash.com/photo-1589998059171-988d887df646?w=200&h=280&fit=crop'},
        {id:'b5',isbn:'9789356291300',title:'The Silent Patient',author:'Alex Michaelides',publisher:'Orion',category:'Thriller',price:450,wholesalePrice:310,cover:'https://images.unsplash.com/photo-1541963463532-d68292c34b19?w=200&h=280&fit=crop'}
      ],
      inventory: [
        {shopId:'s1',bookId:'b1',quantity:45,minStock:10},{shopId:'s1',bookId:'b2',quantity:32,minStock:8},
        {shopId:'s1',bookId:'b3',quantity:18,minStock:5},{shopId:'s1',bookId:'b4',quantity:50,minStock:12},
        {shopId:'s1',bookId:'b5',quantity:7,minStock:5},{shopId:'s2',bookId:'b1',quantity:22,minStock:10},
        {shopId:'s2',bookId:'b2',quantity:15,minStock:8},{shopId:'s2',bookId:'b3',quantity:40,minStock:5}
      ],
      distributorInventory: [
        {distributorId:'u3',bookId:'b1',quantity:500},{distributorId:'u3',bookId:'b2',quantity:350},
        {distributorId:'u3',bookId:'b3',quantity:200},{distributorId:'u3',bookId:'b4',quantity:600},
        {distributorId:'u3',bookId:'b5',quantity:180}
      ],
      orders: [
        {id:'o1',customerId:'u5',shopId:'s1',items:[{bookId:'b1',qty:2,price:399},{bookId:'b3',qty:1,price:350}],total:1148,status:'delivered',paymentStatus:'paid',createdAt:'2026-08-28T10:30:00Z',deliveryId:'d1'},
        {id:'o2',customerId:'u5',shopId:'s1',items:[{bookId:'b2',qty:1,price:499}],total:499,status:'out_for_delivery',paymentStatus:'paid',createdAt:'2026-09-01T14:20:00Z',deliveryId:'d2'},
        {id:'o3',customerId:'u5',shopId:'s2',items:[{bookId:'b4',qty:3,price:299}],total:897,status:'confirmed',paymentStatus:'paid',createdAt:'2026-09-02T09:15:00Z',deliveryId:null}
      ],
      purchaseOrders: [
        {id:'po1',shopId:'s1',distributorId:'u3',items:[{bookId:'b5',qty:30,price:310}],total:9300,status:'dispatched',createdAt:'2026-08-30T11:00:00Z'},
        {id:'po2',shopId:'s1',distributorId:'u3',items:[{bookId:'b2',qty:20,price:350}],total:7000,status:'pending',createdAt:'2026-09-01T16:45:00Z'}
      ],
      deliveries: [
        {id:'d1',orderId:'o1',partnerId:'u4',status:'delivered',trackingCode:'BF-DEL-001',pickedAt:'2026-08-28T12:00:00Z',deliveredAt:'2026-08-28T16:30:00Z'},
        {id:'d2',orderId:'o2',partnerId:'u4',status:'out_for_delivery',trackingCode:'BF-DEL-002',pickedAt:'2026-09-01T15:00:00Z',deliveredAt:null}
      ]
    };
  }
}

function fillLogin(email, pass) {
  document.getElementById('loginEmail').value = email;
  document.getElementById('loginPassword').value = pass;
}

async function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;

  try {
    const data = await api('/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
    currentUser = data.user;
    localStorage.setItem('token', data.token);
    localStorage.setItem('user', JSON.stringify(data.user));
    showApp();
    toast('Welcome back, ' + currentUser.name + '!');
  } catch (err) {
    // Offline login
    const mock = window.__MOCK_DB;
    const user = mock?.users.find(u => u.email === email && u.password === password);
    if (user) {
      const { password: _, ...safe } = user;
      currentUser = safe;
      localStorage.setItem('token', 'demo-token-' + user.id);
      localStorage.setItem('user', JSON.stringify(safe));
      showApp();
      toast('Welcome (offline mode)!');
    } else {
      toast('Invalid credentials');
    }
  }
}

function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  currentUser = null;
  document.getElementById('appLayout').classList.add('hidden');
  document.getElementById('loginPage').classList.remove('hidden');
}

function showApp() {
  document.getElementById('loginPage').classList.add('hidden');
  document.getElementById('appLayout').classList.remove('hidden');
  
  document.getElementById('userName').textContent = currentUser.name;
  document.getElementById('userRole').textContent = currentUser.role.replace('_', ' ');
  document.getElementById('userAvatar').textContent = currentUser.avatar || currentUser.name.slice(0,2).toUpperCase();
  
  renderSidebar();
  navigate('dashboard');
}

// -------------------- SIDEBAR --------------------
const NAV_ITEMS = {
  admin: [
    { section: 'Main', items: [
      { id: 'dashboard', icon: '📊', label: 'Dashboard' },
      { id: 'books', icon: '📚', label: 'Books Catalog' },
      { id: 'shops', icon: '🏪', label: 'Shops' },
      { id: 'inventory', icon: '📦', label: 'Inventory' },
      { id: 'orders', icon: '🛒', label: 'Orders' },
      { id: 'purchase-orders', icon: '📋', label: 'Purchase Orders' },
      { id: 'distributors', icon: '🏭', label: 'Distributors' },
      { id: 'deliveries', icon: '🚚', label: 'Deliveries' },
      { id: 'users', icon: '👥', label: 'Users' },
      { id: 'reports', icon: '📈', label: 'Reports' }
    ]}
  ],
  shop_owner: [
    { section: 'Main', items: [
      { id: 'dashboard', icon: '📊', label: 'Dashboard' },
      { id: 'books', icon: '📚', label: 'Books' },
      { id: 'inventory', icon: '📦', label: 'My Inventory' },
      { id: 'orders', icon: '🛒', label: 'Customer Orders' },
      { id: 'purchase-orders', icon: '📋', label: 'Restock Orders' },
      { id: 'deliveries', icon: '🚚', label: 'Deliveries' }
    ]}
  ],
  distributor: [
    { section: 'Main', items: [
      { id: 'dashboard', icon: '📊', label: 'Dashboard' },
      { id: 'purchase-orders', icon: '📋', label: 'Incoming POs' },
      { id: 'distributor-stock', icon: '📦', label: 'Warehouse Stock' },
      { id: 'deliveries', icon: '🚚', label: 'Dispatches' }
    ]}
  ],
  delivery: [
    { section: 'Main', items: [
      { id: 'dashboard', icon: '📊', label: 'Dashboard' },
      { id: 'deliveries', icon: '🚚', label: 'My Deliveries' }
    ]}
  ],
  customer: [
    { section: 'Main', items: [
      { id: 'dashboard', icon: '🏠', label: 'Home' },
      { id: 'books', icon: '📚', label: 'Browse Books' },
      { id: 'orders', icon: '🛒', label: 'My Orders' }
    ]}
  ]
};

function renderSidebar() {
  const role = currentUser.role;
  const sections = NAV_ITEMS[role] || NAV_ITEMS.admin;
  let html = '';
  sections.forEach(sec => {
    html += `<div class="nav-section"><div class="nav-section-title">${sec.section}</div>`;
    sec.items.forEach(item => {
      html += `<button class="nav-item ${currentPage === item.id ? 'active' : ''}" onclick="navigate('${item.id}')">
        <span class="icon">${item.icon}</span> ${item.label}
      </button>`;
    });
    html += '</div>';
  });
  document.getElementById('sidebarNav').innerHTML = html;
}

function navigate(page) {
  currentPage = page;
  renderSidebar();
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="loading"><div class="spinner"></div> Loading...</div>';
  
  const pages = {
    dashboard: renderDashboard,
    books: renderBooks,
    shops: renderShops,
    inventory: renderInventory,
    orders: renderOrders,
    'purchase-orders': renderPurchaseOrders,
    distributors: renderDistributors,
    'distributor-stock': renderDistributorStock,
    deliveries: renderDeliveries,
    users: renderUsers,
    reports: renderReports
  };
  
  (pages[page] || renderDashboard)();
}

// -------------------- TOAST --------------------
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  setTimeout(() => el.classList.add('hidden'), 3000);
}

// -------------------- DASHBOARD --------------------
async function renderDashboard() {
  const stats = await api('/stats');
  const role = currentUser.role;
  
  let html = `
    <div class="page-header">
      <div>
        <h1>Dashboard</h1>
        <p>Welcome back, ${currentUser.name} 👋</p>
      </div>
    </div>
    <div class="stats-grid">
  `;
  
  if (role === 'admin' || role === 'shop_owner') {
    html += `
      <div class="stat-card lavender"><div class="stat-icon">🏪</div><h3>${stats.totalShops}</h3><p>Active Shops</p></div>
      <div class="stat-card mint"><div class="stat-icon">📚</div><h3>${stats.totalBooks}</h3><p>Books in Catalog</p></div>
      <div class="stat-card peach"><div class="stat-icon">🛒</div><h3>${stats.totalOrders}</h3><p>Total Orders</p></div>
      <div class="stat-card sky"><div class="stat-icon">💰</div><h3>₹${(stats.totalRevenue||0).toLocaleString()}</h3><p>Revenue</p></div>
      <div class="stat-card blush"><div class="stat-icon">⚠️</div><h3>${stats.lowStock}</h3><p>Low Stock Alerts</p></div>
      <div class="stat-card lavender"><div class="stat-icon">🚚</div><h3>${stats.activeDeliveries}</h3><p>Active Deliveries</p></div>
    `;
  } else if (role === 'distributor') {
    html += `
      <div class="stat-card lavender"><div class="stat-icon">📋</div><h3>${stats.pendingOrders}</h3><p>Pending POs</p></div>
      <div class="stat-card mint"><div class="stat-icon">📦</div><h3>${stats.totalBooks}</h3><p>SKU in Warehouse</p></div>
      <div class="stat-card peach"><div class="stat-icon">🚚</div><h3>${stats.activeDeliveries}</h3><p>Active Dispatches</p></div>
    `;
  } else if (role === 'delivery') {
    html += `
      <div class="stat-card sky"><div class="stat-icon">🚚</div><h3>${stats.activeDeliveries}</h3><p>Pending Deliveries</p></div>
      <div class="stat-card mint"><div class="stat-icon">✅</div><h3>${stats.totalOrders - stats.pendingOrders}</h3><p>Completed</p></div>
    `;
  } else {
    html += `
      <div class="stat-card lavender"><div class="stat-icon">📚</div><h3>${stats.totalBooks}</h3><p>Books Available</p></div>
      <div class="stat-card mint"><div class="stat-icon">🛒</div><h3>${stats.totalOrders}</h3><p>Your Orders</p></div>
    `;
  }
  
  html += `</div>`;
  
  // Recent activity
  const orders = await api('/orders');
  html += `
    <div class="card">
      <div class="card-header"><h3>Recent Orders</h3></div>
      <div class="card-body table-wrapper">
        <table>
          <thead><tr><th>Order ID</th><th>Shop</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th></tr></thead>
          <tbody>
            ${orders.slice(0,5).map(o => `
              <tr>
                <td><strong>${o.id}</strong></td>
                <td>${o.shop?.name || '-'}</td>
                <td>${o.customer?.name || '-'}</td>
                <td>₹${o.total}</td>
                <td><span class="badge badge-${o.status}">${o.status.replace(/_/g,' ')}</span></td>
                <td>${new Date(o.createdAt).toLocaleDateString()}</td>
              </tr>
            `).join('') || '<tr><td colspan="6" class="text-muted">No orders yet</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;
  
  document.getElementById('pageContent').innerHTML = html;
}

// -------------------- BOOKS --------------------
async function renderBooks() {
  const books = await api('/books');
  const isAdmin = ['admin','shop_owner'].includes(currentUser.role);
  
  let html = `
    <div class="page-header">
      <div>
        <h1>Books Catalog</h1>
        <p>${books.length} books available</p>
      </div>
      <div class="header-actions">
        <div class="search-box"><input type="text" id="bookSearch" placeholder="Search books..." oninput="filterBooks()"></div>
        ${isAdmin ? '<button class="btn btn-primary" onclick="openBookModal()">+ Add Book</button>' : ''}
      </div>
    </div>
    <div class="books-grid" id="booksGrid">
      ${books.map(b => `
        <div class="book-card" data-title="${b.title.toLowerCase()}" data-author="${b.author.toLowerCase()}">
          <div class="book-cover">
            ${b.cover ? `<img src="${b.cover}" alt="${b.title}" onerror="this.parentElement.innerHTML='📖'">` : '<div class="placeholder">📖</div>'}
          </div>
          <div class="book-info">
            <h4 title="${b.title}">${b.title}</h4>
            <div class="author">${b.author}</div>
            <div class="book-meta">
              <span class="book-price">₹${b.price}</span>
              <span class="book-category">${b.category}</span>
            </div>
          </div>
        </div>
      `).join('')}
    </div>
  `;
  document.getElementById('pageContent').innerHTML = html;
}

function filterBooks() {
  const q = document.getElementById('bookSearch').value.toLowerCase();
  document.querySelectorAll('.book-card').forEach(card => {
    const match = card.dataset.title.includes(q) || card.dataset.author.includes(q);
    card.style.display = match ? '' : 'none';
  });
}

function openBookModal() {
  showModal('Add New Book', `
    <div class="form-group"><label>Title</label><input id="bTitle" required></div>
    <div class="form-row">
      <div class="form-group"><label>Author</label><input id="bAuthor" required></div>
      <div class="form-group"><label>ISBN</label><input id="bIsbn"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Category</label>
        <select id="bCategory"><option>Finance</option><option>Self-Help</option><option>Lifestyle</option><option>Thriller</option><option>Fiction</option></select>
      </div>
      <div class="form-group"><label>Publisher</label><input id="bPublisher"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Selling Price (₹)</label><input type="number" id="bPrice" value="299"></div>
      <div class="form-group"><label>Wholesale Price (₹)</label><input type="number" id="bWholesale" value="200"></div>
    </div>
  `, async () => {
    const body = {
      title: document.getElementById('bTitle').value,
      author: document.getElementById('bAuthor').value,
      isbn: document.getElementById('bIsbn').value,
      category: document.getElementById('bCategory').value,
      publisher: document.getElementById('bPublisher').value,
      price: +document.getElementById('bPrice').value,
      wholesalePrice: +document.getElementById('bWholesale').value
    };
    await api('/books', { method: 'POST', body: JSON.stringify(body) });
    closeModal();
    toast('Book added successfully!');
    renderBooks();
  });
}

// -------------------- SHOPS --------------------
async function renderShops() {
  const shops = await api('/shops');
  let html = `
    <div class="page-header">
      <div><h1>Shops</h1><p>Manage all bookstores</p></div>
      <button class="btn btn-primary" onclick="openShopModal()">+ Add Shop</button>
    </div>
    <div class="card">
      <div class="card-body table-wrapper">
        <table>
          <thead><tr><th>Name</th><th>City</th><th>Address</th><th>Phone</th><th>Status</th></tr></thead>
          <tbody>
            ${shops.map(s => `
              <tr>
                <td><strong>${s.name}</strong></td>
                <td>${s.city}</td>
                <td>${s.address}</td>
                <td>${s.phone || '-'}</td>
                <td><span class="badge badge-success">${s.status}</span></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
  document.getElementById('pageContent').innerHTML = html;
}

function openShopModal() {
  showModal('Add New Shop', `
    <div class="form-group"><label>Shop Name</label><input id="sName" required></div>
    <div class="form-row">
      <div class="form-group"><label>City</label><input id="sCity"></div>
      <div class="form-group"><label>Phone</label><input id="sPhone"></div>
    </div>
    <div class="form-group"><label>Address</label><input id="sAddress"></div>
  `, async () => {
    const body = {
      name: document.getElementById('sName').value,
      city: document.getElementById('sCity').value,
      phone: document.getElementById('sPhone').value,
      address: document.getElementById('sAddress').value,
      ownerId: currentUser.id
    };
    await api('/shops', { method: 'POST', body: JSON.stringify(body) });
    closeModal();
    toast('Shop created!');
    renderShops();
  });
}

// -------------------- INVENTORY --------------------
async function renderInventory() {
  const inv = await api('/inventory');
  let html = `
    <div class="page-header">
      <div><h1>Inventory</h1><p>Stock levels across shops</p></div>
    </div>
    <div class="card">
      <div class="card-body table-wrapper">
        <table>
          <thead><tr><th>Book</th><th>Shop</th><th>Quantity</th><th>Min Stock</th><th>Status</th></tr></thead>
          <tbody>
            ${inv.map(i => {
              const low = i.quantity <= i.minStock;
              return `
                <tr>
                  <td><strong>${i.book?.title || i.bookId}</strong><br><span class="text-sm text-muted">${i.book?.author || ''}</span></td>
                  <td>${i.shop?.name || i.shopId}</td>
                  <td><strong>${i.quantity}</strong></td>
                  <td>${i.minStock}</td>
                  <td><span class="badge ${low ? 'badge-danger' : 'badge-success'}">${low ? 'Low Stock' : 'In Stock'}</span></td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
  document.getElementById('pageContent').innerHTML = html;
}

// -------------------- ORDERS --------------------
async function renderOrders() {
  const orders = await api('/orders');
  let html = `
    <div class="page-header">
      <div><h1>Orders</h1><p>Customer orders across shops</p></div>
    </div>
    <div class="card">
      <div class="card-body table-wrapper">
        <table>
          <thead><tr><th>ID</th><th>Customer</th><th>Shop</th><th>Items</th><th>Total</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>
          <tbody>
            ${orders.map(o => `
              <tr>
                <td><strong>${o.id}</strong></td>
                <td>${o.customer?.name || '-'}</td>
                <td>${o.shop?.name || '-'}</td>
                <td>${o.items?.length || 0} item(s)</td>
                <td>₹${o.total}</td>
                <td><span class="badge badge-${o.status}">${o.status.replace(/_/g,' ')}</span></td>
                <td>${new Date(o.createdAt).toLocaleDateString()}</td>
                <td>
                  ${o.status !== 'delivered' && o.status !== 'cancelled' ? `
                    <select onchange="updateOrderStatus('${o.id}', this.value)" style="padding:4px 8px;border-radius:6px;border:1px solid #EDE4F5;">
                      <option value="">Update...</option>
                      <option value="confirmed">Confirmed</option>
                      <option value="packed">Packed</option>
                      <option value="out_for_delivery">Out for Delivery</option>
                      <option value="delivered">Delivered</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  ` : '-'}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
  document.getElementById('pageContent').innerHTML = html;
}

async function updateOrderStatus(id, status) {
  if (!status) return;
  await api(`/orders/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
  toast('Order status updated');
  renderOrders();
}

// -------------------- PURCHASE ORDERS --------------------
async function renderPurchaseOrders() {
  const pos = await api('/purchase-orders');
  let html = `
    <div class="page-header">
      <div><h1>Purchase Orders</h1><p>Shop → Distributor restock requests</p></div>
      ${['admin','shop_owner'].includes(currentUser.role) ? '<button class="btn btn-primary" onclick="openPOModal()">+ New PO</button>' : ''}
    </div>
    <div class="card">
      <div class="card-body table-wrapper">
        <table>
          <thead><tr><th>PO ID</th><th>Shop</th><th>Distributor</th><th>Items</th><th>Total</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>
          <tbody>
            ${pos.map(po => `
              <tr>
                <td><strong>${po.id}</strong></td>
                <td>${po.shop?.name || '-'}</td>
                <td>${po.distributor?.name || '-'}</td>
                <td>${po.items?.map(i => `${i.book?.title || i.bookId} ×${i.qty}`).join(', ')}</td>
                <td>₹${po.total}</td>
                <td><span class="badge badge-${po.status}">${po.status}</span></td>
                <td>${new Date(po.createdAt).toLocaleDateString()}</td>
                <td>
                  ${po.status === 'pending' && currentUser.role === 'distributor' ? `
                    <button class="btn btn-mint btn-sm" onclick="updatePOStatus('${po.id}','dispatched')">Dispatch</button>
                  ` : '-'}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
  document.getElementById('pageContent').innerHTML = html;
}

async function updatePOStatus(id, status) {
  await api(`/purchase-orders/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
  toast('Purchase order updated');
  renderPurchaseOrders();
}

function openPOModal() {
  showModal('Create Purchase Order', `
    <div class="form-group"><label>Shop ID</label><input id="poShop" value="s1"></div>
    <div class="form-group"><label>Distributor ID</label><input id="poDist" value="u3"></div>
    <div class="form-group"><label>Book ID</label><input id="poBook" value="b2"></div>
    <div class="form-row">
      <div class="form-group"><label>Quantity</label><input type="number" id="poQty" value="20"></div>
      <div class="form-group"><label>Unit Price</label><input type="number" id="poPrice" value="350"></div>
    </div>
  `, async () => {
    const qty = +document.getElementById('poQty').value;
    const price = +document.getElementById('poPrice').value;
    const body = {
      shopId: document.getElementById('poShop').value,
      distributorId: document.getElementById('poDist').value,
      items: [{ bookId: document.getElementById('poBook').value, qty, price }],
      total: qty * price
    };
    await api('/purchase-orders', { method: 'POST', body: JSON.stringify(body) });
    closeModal();
    toast('Purchase order created!');
    renderPurchaseOrders();
  });
}

// -------------------- DISTRIBUTORS --------------------
async function renderDistributors() {
  const dists = await api('/distributors');
  let html = `
    <div class="page-header">
      <div><h1>Distributors</h1><p>Middle parties in the supply chain</p></div>
    </div>
    <div class="card">
      <div class="card-body table-wrapper">
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th></tr></thead>
          <tbody>
            ${dists.map(d => `
              <tr>
                <td><strong>${d.name}</strong></td>
                <td>${d.email}</td>
                <td><span class="badge badge-purple">${d.role}</span></td>
                <td><span class="badge badge-success">Active</span></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
  document.getElementById('pageContent').innerHTML = html;
}

async function renderDistributorStock() {
  const stock = await api('/distributor-inventory');
  let html = `
    <div class="page-header">
      <div><h1>Warehouse Stock</h1><p>Distributor inventory levels</p></div>
    </div>
    <div class="card">
      <div class="card-body table-wrapper">
        <table>
          <thead><tr><th>Book</th><th>Author</th><th>Quantity</th><th>Category</th></tr></thead>
          <tbody>
            ${stock.map(s => `
              <tr>
                <td><strong>${s.book?.title || s.bookId}</strong></td>
                <td>${s.book?.author || '-'}</td>
                <td><strong>${s.quantity}</strong></td>
                <td><span class="book-category">${s.book?.category || '-'}</span></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
  document.getElementById('pageContent').innerHTML = html;
}

// -------------------- DELIVERIES --------------------
async function renderDeliveries() {
  const dels = await api('/deliveries');
  let html = `
    <div class="page-header">
      <div><h1>Deliveries</h1><p>Track shipments & proof of delivery</p></div>
    </div>
    <div class="card">
      <div class="card-body table-wrapper">
        <table>
          <thead><tr><th>Tracking</th><th>Order</th><th>Partner</th><th>Status</th><th>Picked</th><th>Delivered</th><th>Action</th></tr></thead>
          <tbody>
            ${dels.map(d => `
              <tr>
                <td><strong>${d.trackingCode}</strong></td>
                <td>${d.orderId}</td>
                <td>${d.partner?.name || '-'}</td>
                <td><span class="badge badge-${d.status}">${d.status.replace(/_/g,' ')}</span></td>
                <td>${d.pickedAt ? new Date(d.pickedAt).toLocaleString() : '-'}</td>
                <td>${d.deliveredAt ? new Date(d.deliveredAt).toLocaleString() : '-'}</td>
                <td>
                  ${d.status !== 'delivered' && (currentUser.role === 'delivery' || currentUser.role === 'admin') ? `
                    <button class="btn btn-mint btn-sm" onclick="markDelivered('${d.id}')">Mark Delivered</button>
                  ` : '-'}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
  document.getElementById('pageContent').innerHTML = html;
}

async function markDelivered(id) {
  await api(`/deliveries/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'delivered' }) });
  toast('Delivery marked as completed!');
  renderDeliveries();
}

// -------------------- USERS --------------------
async function renderUsers() {
  const users = await api('/users');
  let html = `
    <div class="page-header">
      <div><h1>Users</h1><p>All system users & roles</p></div>
    </div>
    <div class="card">
      <div class="card-body table-wrapper">
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Shop</th></tr></thead>
          <tbody>
            ${users.map(u => `
              <tr>
                <td>
                  <div class="flex items-center gap-2">
                    <div class="user-avatar" style="width:32px;height:32px;font-size:12px">${u.avatar || u.name.slice(0,2)}</div>
                    <strong>${u.name}</strong>
                  </div>
                </td>
                <td>${u.email}</td>
                <td><span class="badge badge-purple">${u.role.replace('_',' ')}</span></td>
                <td>${u.shopId || '-'}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
  document.getElementById('pageContent').innerHTML = html;
}

// -------------------- REPORTS --------------------
async function renderReports() {
  const stats = await api('/stats');
  const orders = await api('/orders');
  
  let html = `
    <div class="page-header">
      <div><h1>Reports & Analytics</h1><p>Business insights</p></div>
    </div>
    <div class="stats-grid">
      <div class="stat-card lavender"><div class="stat-icon">💰</div><h3>₹${(stats.totalRevenue||0).toLocaleString()}</h3><p>Total Revenue</p></div>
      <div class="stat-card mint"><div class="stat-icon">🛒</div><h3>${stats.totalOrders}</h3><p>Orders Processed</p></div>
      <div class="stat-card peach"><div class="stat-icon">📦</div><h3>${stats.lowStock}</h3><p>Low Stock Items</p></div>
      <div class="stat-card sky"><div class="stat-icon">🏪</div><h3>${stats.totalShops}</h3><p>Active Shops</p></div>
    </div>
    <div class="card">
      <div class="card-header"><h3>Orders by Status</h3></div>
      <div class="card-body">
        <div style="display:flex;gap:16px;flex-wrap:wrap;">
          ${['confirmed','out_for_delivery','delivered','cancelled'].map(st => {
            const count = orders.filter(o => o.status === st).length;
            return `<div style="flex:1;min-width:120px;background:var(--lilac);padding:16px;border-radius:12px;text-align:center">
              <div style="font-size:24px;font-weight:700">${count}</div>
              <div class="text-sm text-muted">${st.replace(/_/g,' ')}</div>
            </div>`;
          }).join('')}
        </div>
      </div>
    </div>
  `;
  document.getElementById('pageContent').innerHTML = html;
}

// -------------------- MODAL HELPERS --------------------
function showModal(title, bodyHtml, onSave) {
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <h3>${title}</h3>
          <button class="modal-close" onclick="closeModal()">×</button>
        </div>
        <div class="modal-body">${bodyHtml}</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
          <button class="btn btn-primary" id="modalSaveBtn">Save</button>
        </div>
      </div>
    </div>
  `;
  document.getElementById('modalSaveBtn').onclick = onSave;
}

function closeModal() {
  document.getElementById('modalRoot').innerHTML = '';
}
