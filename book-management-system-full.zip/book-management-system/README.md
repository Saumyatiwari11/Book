# 📚 BookFlow – Multi-Shop Book Management System

A complete full-stack Book Management & Supply Chain system supporting:
- Multiple Shops
- Multiple Users (Admin, Shop Owner, Staff, Customer)
- Multiple Middle Parties (Distributors / Wholesalers / Delivery Partners)
- End-to-end flow: Publisher → Distributor → Shop → Customer

## 🎨 Design
Soft pastel color palette (lavender, mint, peach, sky, blush) for a modern, calm and professional look.

## 🛠 Tech Stack
- **Frontend**: HTML5 + CSS3 (Custom pastel theme) + Vanilla JavaScript (SPA)
- **Backend**: Node.js + Express
- **Storage**: JSON file based (easy to replace with MongoDB / PostgreSQL)
- **Auth**: Simple JWT-style token (demo)

## 📁 Folder Structure
```
book-management-system/
├── frontend/
│   ├── index.html
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   ├── app.js
│   │   ├── auth.js
│   │   ├── api.js
│   │   └── components.js
│   └── assets/
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── routes/
│   │   ├── auth.js
│   │   ├── books.js
│   │   ├── shops.js
│   │   ├── orders.js
│   │   ├── inventory.js
│   │   ├── distributors.js
│   │   └── deliveries.js
│   └── data/
│       └── db.json
├── docs/
└── README.md
```

## 🚀 How to Run

### 1. Backend
```bash
cd backend
npm install
npm start
```
Server runs at: http://localhost:5000

### 2. Frontend
Simply open `frontend/index.html` in browser  
**OR** serve it:
```bash
cd frontend
npx serve .
```

## 👥 Demo Accounts
| Role              | Email                    | Password  |
|-------------------|--------------------------|-----------|
| Super Admin       | admin@bookflow.com       | admin123  |
| Shop Owner        | owner@shop.com           | owner123  |
| Distributor       | dist@warehouse.com       | dist123   |
| Delivery Partner  | delivery@courier.com     | del123    |
| Customer          | customer@mail.com        | cust123   |

## ✅ Features Included
- Role-based dashboards
- Book Catalog + Inventory (multi-shop)
- Shop Management
- Order Management (Customer + Purchase Orders)
- Distributor / Middle-party module
- Delivery tracking
- Soft pastel modern UI with responsive design
- Sidebar navigation with all main tabs
- Search, filters, status badges, cards, tables

## 📌 Next Steps (Production)
- Replace JSON store with MongoDB / PostgreSQL
- Add real JWT + bcrypt
- Integrate Razorpay / Stripe
- Add WhatsApp / Email notifications
- Deploy frontend (Vercel) + backend (Render / Railway)
